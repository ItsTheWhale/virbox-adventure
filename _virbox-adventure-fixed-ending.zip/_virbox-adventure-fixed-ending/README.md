# Virbox Adventure

Run it in any web server of your choice, and open index.html.

Documentation is provided via the in-game "help" command.